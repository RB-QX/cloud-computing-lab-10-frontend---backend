import logo from "./logo.svg";
import "./App.css";
import axios from 'axios'
import { Auth0Provider, useAuth0 } from "@auth0/auth0-react";
import { useState } from "react";
function App() {
  const { user, loginWithRedirect, logout, isAuthenticated } = useAuth0();
  let [dbsave,setDbsave] = useState(false);
  return (
    <div className="App">
      <header className="App-header">
        {/* {
          isAuthenticated ? (<h2> Hello {user.name} </h2>) : ()
        } */}
        {isAuthenticated ? (
          <>
          <h1>Hello {user.name}</h1>
          <button style={{height:'100px', margin:'100px'}} onClick={async()=>{
          try{
            setDbsave(false);
            let data = await axios.post('http://localhost:3001/data',{
            ...user
           })
           console.log(data)
           if(data.data==='ok')setDbsave(true);
           setTimeout(()=>{setDbsave(false)},5000);

          }
          catch(err){
            setDbsave(false);
            console.log(err);
          }
           
          }}>Send Data to Database</button>
          <button className="btn"
            onClick={() =>
              logout({ logoutParams: { returnTo: window.location.origin } })
            }
          >
            Logout
          </button>
          </>
        ) : (
          <>
          <h1>Hello user, Please login</h1>
          <button className="btn" onClick={() => loginWithRedirect()}>
            LOGIN
          </button>
          </>
        )}
        {dbsave===true?<h1>data saved, message will be removed in 5 seconds</h1>:<h1></h1>}
      </header>
    </div>
  );
}

export default App;