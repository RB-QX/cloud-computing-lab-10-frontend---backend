# Cloud Computing Lab project
 This is my final lab made by using auth0 for single sign on and docker  for giving a runtime platform.
