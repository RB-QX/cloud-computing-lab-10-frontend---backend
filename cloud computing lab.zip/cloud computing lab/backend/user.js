const mongoose = require("mongoose");

// Define the User schema
const userSchema = new mongoose.Schema({
  username: { type: String, required: true },
  email: { 
    type: String, 
    required: true, 
    unique: true, 
    match: /^\S+@\S+\.\S+$/, // Simple email format validation
  },
});

// Create the User model from the schema
const User = mongoose.model("User", userSchema);

module.exports = User;
