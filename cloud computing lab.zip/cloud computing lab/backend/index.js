let express = require('express')
let mongoose = require('mongoose')
let cors = require('cors')
let app = express();
let User = require('./user')
mongoose.connect('mongodb+srv://rachitreal14052003rb:PDqeZXaYJMozSTBX@cluster0.voi86yc.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0').then(p=>console.log('db connected')).catch(err=>console.log(err))
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({extended:true}))
app.listen(3001,()=>{
    console.log('server running')
})

app.get('/',(req,res)=>{
    return res.send('running server')
})
app.post('/data',async (req,res)=>{
   try{
    console.log(req.body);
    let data = new User({
        username:`${req.body.given_name} ${req.body.family_name}`,
        email:req.body.email
    })
    let _data = await data.save();
    console.log(_data);
    res.status(200).send('ok')
   }
   catch(err){
    console.log('error man')
    res.status(403).send('something went wrong')
   }

});